import './App.css';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField'
import React, { useState } from "react";


function Projects(){
  return(
    <div>
      <h1>Projects</h1>
      <ProjectList name = "1" availabileSets = {100}/>
      <ProjectList name = "2" availabileSets = {100}/>
      <ProjectList name = "3" availabileSets = {100}/>
    </div>
  );
}

function ProjectList(props){
  const[joinPressed, setStatus] = useState(false); 
  const[joinButton, setjoinText] = useState("Join"); 

  const changeJoinState = () => {
    if(joinPressed){
      setjoinText("Join");
      setStatus(false);   
    } 
    else{
      setjoinText("Leave"); 
      setStatus(true); 
    }
  }

  return (
    <div class = "box" style={{
      backgroundColor: joinPressed ? '#00B74A' : '',
    }} >
      <h2>Project Name {props.name}</h2>
      <p>list, of, authorized, users</p>
    <div>
      <HWSet name = "1" availabileSets = {props.availabileSets}/>
      <HWSet name = "2" availabileSets = {props.availabileSets}/>
    </div>
      <Button sx={{ m: 2 }} variant="contained" onClick={(e) => {changeJoinState()}}>{joinButton}</Button>
    </div>
  );
}

function HWSet(props){
  let sets = parseInt(props.availabileSets, 10); 
  const [textValue, setValue] = useState(""); 
  const[availableSets, setState] = useState(sets);

  const CheckIn = (val) => {
    if(parseInt(availableSets, 10) +parseInt(val, 10) <= sets){
      let x = (parseInt(availableSets, 10) + parseInt(val, 10)); 
      setState(x); 
    }
    else{
      setState(parseInt(props.availableSets, 10)); 
    }
  }

  const CheckOut = (val) => {
    if(parseInt(val, 10) < parseInt(availableSets, 10)){
      let x = (parseInt(availableSets, 10) - parseInt(val, 10)); 
      setState(x); 
    }
    else{
      setState(0); 
    }
  }

  return(
    <div>
      <h3> HWSet{props.name}: {availableSets}/{props.availabileSets}</h3>
      <TextField sx = {{m: 2}} id = "outlined-basic" label = "Enter Quantity" variant = "outlined"
        value = {textValue} onChange = {(clicked) => {
          setValue(clicked.target.value);}}/>
      <Button sx={{ m:2 }} onClick={(clicked) => {CheckIn(textValue)}} variant = "contained">Check In</Button>
      <Button sx={{ m:2 }} onClick={(clicked) => {CheckOut(textValue)}} variant = "contained">Check Out</Button>
    </div>
  );
}

function App(){
  return(
    <Projects />
  );
}

export default App;
